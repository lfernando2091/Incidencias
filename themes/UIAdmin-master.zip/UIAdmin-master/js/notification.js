// Create an instance of Notyf
var notyf = new Notyf();

setTimeout(function() {
	notyf.confirm('Welcome to UI Admin!!');
}, 500);
